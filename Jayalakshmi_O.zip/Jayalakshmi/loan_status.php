<?php
  include_once "inc/header.php";
  include_once "inc/sidebar.php";
?>

<div class="card">
  <div class="card-header">
    Loan Status
  </div>
  <div class="card-body">
    	<h5 class="card-title">Outstanding Loan Details</h5>
		<table id="example" class="table table-striped table-bordered table-hover" cellspacing="0" width="100%">
	        <thead>
	            <tr>
	                <th>gl_no </th>
	                <th>item_description</th>
	                <th>gross_weight</th>
	                <th>stone_weight</th>
	                <th>net_weight</th>
	                <th>market_value</th>
	                <th>loan_amnt</th>
	              <th>b_id</th>
	                <th>date</th>
	                <th>closing_date</th>
	                <th>Status</th>
	             <th>file</th>

	            </tr>
	        </thead>

	        <tbody>
	        	<?php 
	        		$all = $ml->getGoldLoanStatus();
	        		if ($all) {
	        			$i = 1;
	        			while ($row = $all->fetch_assoc()) {
	        				$i++;

	        	 ?>
	            <tr>
	                <td><?php echo $row['gl_no']; ?></td>
	                <td><?php echo $row['item_description']; ?></td>
	                <td><?php echo $row['gross_weight']; ?> </td>
	                <td><?php echo $row['stone_weight']; ?></td>
	                <td><?php echo $row['net_weight']; ?> </td>
	                <td><?php echo $row['market_value']; ?></td>
	                <td><?php echo $row['loan_amnt']; ?></td>
	                <td><?php //echo $row['b_id']; ?> </td>
	                <td><?php echo $row['date']; ?></td>
	                <td><?php echo $row['closing_date']; ?></td>
	                <td><?php //echo $row['Status']; ?></td>
	                
					
	            </tr>
				<?php 
	        			}
	        		}
				 ?>
	        </tbody>
	    </table>
	  </div>
	</div>

<?php
include_once "inc/footer.php";
?>