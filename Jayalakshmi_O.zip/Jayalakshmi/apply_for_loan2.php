 <?php
  include_once "inc/header.php";
  include_once "inc/sidebar.php";
?>


       <script>
        function calculateEMI() {
            
            var item_description=document.myform.item_description.value;
              if (!item_description)
                item_description = null;
            
            var gross_weight = document.myform.gross_weight.value;
            if (!gross_weight)
                gross_weight = '0';

             var stone_weight = document.myform.stone_weight.value;
            if (!stone_weight)
                stone_weight = '0';
            


            var market_value =document.myform.market_value.value;
            if (!market_value)
                market_value = '0';

            
            var gross_weight = parseFloat(gross_weight);
            var stone_weight = parseFloat(stone_weight);
            var net_weight   =gross_weight-stone_weight;

            var loan_amount = net_weight*(market_value*(80/100));
            document.myform.net_weight.value = parseFloat(net_weight).toFixed(2);
            document.myform.loan_amount.value=parseFloat(loan_amount);
		
		// Get the current date in the format "YYYY-MM-DD"
var currentDate = new Date();
var year = currentDate.getFullYear();
var month = (currentDate.getMonth() + 1).toString().padStart(2, '0');
var day = currentDate.getDate().toString().padStart(2, '0');
var dateString = year + '-' + month + '-' + day;

// Create a JavaScript Date object
var dateObject = new Date(dateString);

// Format the date to "DD-MM-YYYY"
var outputDate = dateObject.getDate().toString().padStart(2, '0') + '-' +
                  (dateObject.getMonth() + 1).toString().padStart(2, '0') + '-' +
                  dateObject.getFullYear();

// Add 365 days to the date
dateObject.setDate(dateObject.getDate() + 365);

// Format the due date to "DD-MM-YYYY"
var due_date = dateObject.getDate().toString().padStart(2, '0') + '-' +
              (dateObject.getMonth() + 1).toString().padStart(2, '0') + '-' +
              dateObject.getFullYear();
document.myform.due_date.value=due_date;

}

   
        function getItem() {
       //  var e = document.getElementById("item_description");
 // document.myform.other_item_description.value = e.options[e.selectedIndex].value;

var other_item_description = document.getElementById("other_item_description");

other_item_description.value=Array.prototype.filter.call( document.getElementById("item_description").options,el => el.selected).map(el => el.value).join(",");
  }
  
       
      </script>


  <?php 
        if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit_loan_application'])) {
        $inserted = $ml->applyForLoan($_POST,$_FILES);
    }    
   ?>
        <h3 class="page-heading mb-4">Gold Loan application form</h3>
        <h5 class="card-title p-3 bg-info text-white rounded">Fill up loan details</h5>
        <div class="container">
          <?php
          
          if (isset($inserted)){
          ?>
          <div id="successMessage" class="alert alert-success alert-dismissible">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
              <?php  echo $inserted; ?>
         </div>
<?php
 if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['search'])){

 require('fpdf186/fpdf.php'); 
  $date = date("Y-m-d");
$date1 = new DateTime($date);
$outputDate = $date1->format('d-m-Y');
/* $due_date_object = new DateTime($outputDate);
$due_date_object->modify('+365 days');
$due_date = $due_date_object->format('d-m-Y'); */

// Instantiate and use the FPDF class  
$pdf = new FPDF(); 
  

//Add a new page 
$pdf->AddPage(); 
$customer_name=$_POST['borrower_name'];
$mobile=$_POST['key'];

 // $mobile = isset($_POST['mobile']) ? $_POST['mobile'] : null;
 $b_id=$_POST['b_id'];
$gl_no=$_POST['gl_no'];
 // $date=date("Y-m-d");
// $outputDate = $date->format('d-m-Y');
$item_description=$_POST['other_item_description'];
$net_weight=$_POST['net_weight'];
$loan_amount=$_POST['loan_amount'];
$due_date=$_POST['due_date'];

$br = $emp->findBorrowerByMobile($mobile);

if ($br) {
    $row = $br->fetch_assoc();
    //$name = $row['name'];
 $name = isset($row['name']) ? $row['name'] : null;

    //$b_id = $row['id'];
$b_id = isset($row['id']) ? $row['id'] : null;

$cmr = $emp->getCustomerDetails($b_id);
if($cmr)
{
 $row = $cmr->fetch_assoc();
$addr=$row['address'];
$mob=$row['mobile'];
$image=$row['image'];

    // Prepare report data
    $report_data = [
        'GL Number' => $gl_no,
        'Name' => $name,
        'Borrower ID' => $b_id,
       'Address' => $addr,
        'Mobile' => $mob,
       
        'Date' => $outputDate,
        // 'Item Description' => implode(", ", $item_description),
         'Item Description' => $item_description,
        'Net Weight' => $net_weight,
        'Loan Amount' => $loan_amount,
       'Customer'=> $image,
       'Due Date' =>$due_date
    ];



$customer_name=$_POST['borrower_name'];
// $mobile=$_POST['key'];
$br = $emp->findBorrowerByMobile($mobile);
$row = $br->fetch_assoc();
 $b_id = $row['id'];
$cmr = $emp->getCustomerDetails($b_id);
if($cmr)
{
 $row = $cmr->fetch_assoc();
$addr=$row['address'];
$mob=$row['mobile'];
$image=$row['image'];
}


$pdf->SetFont('Arial', 'B', 22);

// Add some text
$pdf->Cell(0, 0, 'Jayalakshmi Enterprises',0,1,'C');
$pdf->Cell(0, 15, 'Manapaady,Thanisserry P.O.',0,1,'C');
$pdf->Cell(20, 60, 'Pledge Form',0,1,'L');

$pdf->SetFont('Times', '', 12); // Set different font for body text
 foreach ($report_data as $label => $value):
$pdf->MultiCell(0, 8, "$label: $value",0,'L');

endforeach;
	
$pdf->Cell(20, 20, $customer_name); $pdf->Cell(60, 20, "Signature");
$pdfPath = "my_generated_pdf.pdf";		
// $pdf->Output($pdfPath, 'F');

// echo "<a href='$pdfPath' download>Download PDF</a>";

if ($pdf->Output($pdfPath, 'F')) {
    echo "PDF generated successfully at: $pdfPath";
} else {
    echo "Failed to generate PDF";
}


          }?> 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Loan Application Report</title>
    <style>
        table {
            border-collapse: collapse;
            width: 50%;
            margin: 20px;
        }

        table, th, td {
            border: 0px solid black;
        }

        th, td {
            padding: 8px;
            text-align: left;
        }
    </style>
</head>
<body>
<h1 align="middle">Jayalakshmi Enterprises<br>Kml                       No:<br>Manapaady,Thanisserry P.O.</h1>
    <h3>Loan Application Report</h3>
    <table border="0">
<tr>
<td></td>
<td><img src="'admin/uploads/<?php  echo $image ?>'" width='100'></td>
</tr>
        <?php foreach ($report_data as $label => $value): ?>

            <tr>
                <td><?php echo $label; ?></td>
                <td><?php echo $value; ?></td>
            </tr>
        <?php endforeach; ?>
	<tr>
		<td><?php echo $customer_name; ?></td>
		<td></td>
</tr>

    </table>
<button onclick="printPDF()">Print PDF</button>

    <script>
        function printPDF() {
            var pdfWindow = window.open('<?php echo $pdfPath; ?>');
            pdfWindow.onload = function() {
                pdfWindow.print();
            };
        }
    </script>
</body>
</html>

          

          <?php 

}
}
}
       
 else {
           // echo "Error inserting data into the database.";          
 }
           $name = "";
$b_id = "";
// $mobile="";

 // Create an instance of the CrudOperation class
$crud = new CrudOperation();

// Escape the string using the real_escape_string method
$searchKey = isset($_POST['key']) ? $crud->escapeString($_POST['key']) : '';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['search'])) {
    $searchMobile = intval($searchKey);

    $br = $emp->findBorrowerByMobile($searchMobile);

    if ($br === false) {
        echo "Database error: " . $emp->db->error;
    } elseif ($br->num_rows > 0) {
        $row = $br->fetch_assoc();

        if ($row && isset($row['name']) && isset($row['mobile']) && isset($row['id'])) {
            $name = $row['name'];
            $mobile = $row['mobile'];
            $b_id = $row['id'];
            // Process the data
        } else {
            echo "Invalid data structure in the result set";
        }
    } else {
        echo "No data found for the specified criteria";
    }
}
?>




          <form action="<?php echo $_SERVER['PHP_SELF'];?>" method="POST" autocomplete="off">
                <div class="form-group row">
              <label for="inputBorrowerFirstName" class="text-right col-2 font-weight-bold col-form-label">Search brrower: </label>                      
              <div class="col-sm-6">
                  <input type="text" name="key" class="form-control" id="inputBorrowerFirstName" placeholder="Enter Mobile Number of borrower" required>
              </div>
              <div class="col-sm-3">
                <input type="submit" class="btn btn-info" name="search" value="Search">
              </div>  
            </div>

          </form>  

          <form action="<?php echo $_SERVER['PHP_SELF'];?>" method="post" enctype="multipart/form-data" name="myform" id="myform" autocomplete="off">
            </div>
<!--Added Borrower Name-->
            <div class="form-group row">
              <label for="borrower_name" class="text-right col-2 font-weight-bold col-form-label">Borrower Name</label>                      
              <div class="col-sm-9">
                  <input type="text"  name="borrower_name" class="form-control" value="<?php echo $name; ?>" readonly>
              </div>
            </div>

            <!--Added Borrower ID-->
            <div class="form-group row">
              <label for="borrower_id" class="text-right col-2 font-weight-bold col-form-label">Borrower ID</label>                      
              <div class="col-sm-9">
                  <input type="text"  name="b_id" class="form-control" value="<?php echo $b_id; ?>" readonly>
              </div>
            </div>

           
<!--Gl_No -->
            <div class="form-group row">
              <label for="gl_no" class="text-right col-2 font-weight-bold col-form-label">GL Number</label>                      
              <div class="col-sm-9">
                  <input type="text"  name="gl_no" class="form-control"  >
              </div>
            </div>

            <div class="form-group row">
              <label for="item_description" class="text-right col-2 font-weight-bold col-form-label">Item description</label>                      
              <div class="col-sm-9">
                 
<!--Item Description-->

<label for="item_description">Select an item:</label>

<select id="item_description" name="item_description[]" multiple onchange=getItem()>
  <option value="Chain">Chain</option>
  <option value="Bangle">Bangle</option>
  <option value="Ring">Ring</option>
  <option value="ear ring">ear ring</option>
<option value="others">others</option>
</select>
<input type="text" placeholder="selected_item" id="other_item_description" name="other_item_description">
              </div>


            </div>


            <div class="form-group row">
              <label for="gross_weight" class="text-right col-2 font-weight-bold col-form-label">gross_weight</label>                      
              <div class="col-sm-9">
                  <input type="number" onkeyup="calculateEMI()" name="gross_weight" class="form-control" id="gross_weight" min="0"  step="0.01" placeholder="Enter gross_weight" required>
              </div>
            </div>

            <div class="form-group row">
                <label  class="text-right col-2 font-weight-bold col-form-label">Stone weight</label>                      
                 <div class="col-sm-9">
                  <input type="number" onkeyup="calculateEMI()" name="stone_weight" class="form-control" id="stone_weight" min="0"  step="0.01" placeholder="Enter Stone weight" required>
              </div>
            </div> 
            
             <div class="form-group row">
                <label  class="text-right col-2 font-weight-bold col-form-label">Net Weight</label>                      
                 <div class="col-sm-9">
                  <input type="text"  id="net_weight" name="net_weight" class="form-control" readonly required>
              </div>
            </div> 

            <div class="form-group row">
                <label for="market_value" class="text-right col-2 font-weight-bold col-form-label">Market Value</label>  
                <div class="col-sm-9">
                    <input type="number" onkeyup="calculateEMI()" name="market_value" class="form-control" id="market_value"  required>
                </div>
            </div>
<div class="form-group row">
                <label for="loan_amount" class="text-right col-2 font-weight-bold col-form-label">Loan Amount</label>  
                <div class="col-sm-9">
                    <input type="text" name="loan_amount" class="form-control positive-integer" id="loan_amount"  required>
                </div>
            </div>
<div class="form-group row">
                <label for="due_date" class="text-right col-2 font-weight-bold col-form-label">Due Date</label>  
                <div class="col-sm-9">
                    <input type="text" name="due_date" class="form-control positive-integer" id="due_date"  onkeyup="calculateEMI()"  readonly required>
                </div>
            </div>
          <hr>
          <div class="form-group row">
              <label for="gold_images" class="text-right font-weight-bold col-2 col-form-label">Gold Images<br></label>
              <div class="col-sm-9">    
                  <input type="file"  id="gold_photo_file" name="image" required>
              </div>
          </div>
             <hr>
          <div class="form-group row">
              <div class="col-md-6">

              <input type="submit" name="submit_loan_application" class="btn btn-info pull-right" value="Submit Application">

              </div>
            
        </form>
       </div> 
 <hr>
          <div class="form-group row">
              <div class="col-md-6">
      


 <!--  </form> -->    
</div><!-- /.box-footer --> 
</div>
  
              
<?php
include_once "inc/footer.php";
?>