<!-- partial -->
    <div class="container-fluid">
      <div class="row row-offcanvas row-offcanvas-right">
        <!-- partial:partials/_sidebar.html -->
        <nav class="bg-white sidebar sidebar-offcanvas" id="sidebar">
          <div class="user-info">
            <img src="images/user.jpeg" alt="">
            <p class="name"><?php echo Session::get("name");?></p>
            <p class="designation"><?php echo Session::get("designation");?></p>
            <span class="online"></span>
          </div>
          <ul class="nav">
            <li class="nav-item active">
              <a class="nav-link" href="index.php">
                <img src="images/icons/1.png" alt="">
                <span class="menu-title">Dashboard</span>
              </a>
            </li>

          <?php if(Session::get("role") == 2){?>
          <!-- borrower option -->
            <li class="nav-item">
              <a class="nav-link" data-toggle="collapse" href="#borrower-pages" aria-expanded="false" aria-controls="borrower-pages">
                <img src="images/icons/9.png" alt="">
                <span class="menu-title">Borrower<i class="fa fa-sort-down"></i></span>
              </a>
              <div class="collapse" id="borrower-pages">
                <ul class="nav flex-column sub-menu">
                  <li class="nav-item">
                    <a class="nav-link" href="addborrower.php">Add Borrower</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="viewborrower.php">View Borrower</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="update.php">Update Borrower</a>
                  </li>
<li class="nav-item">
                    <a class="nav-link" href="search.php">Search  Borrower</a>
                  </li>
                </ul>
              </div>
            </li>
            <!-- end borrower option -->
         <!-- Gold loan option -->
            <li class="nav-item">
           <!--   <a class="nav-link" data-toggle="collapse" href="" aria-expanded="false" aria-controls="goldloan-pages"> -->
              <a class="nav-link" href="apply_for_loan1.php">
                <img src="images/icons/4.png" alt="">
                <span class="menu-title">Apply for loan<i class="fa fa-sort-                                down"></i></span>
              </a>
<div class="collapse" id="goldloan-pages">
                <ul class="nav flex-column sub-menu">
                  <li class="nav-item">
                    <a class="nav-link" href="apply_for_loan1.php">Add Gold Loan</a>
                  </li>
                  
 <li class="nav-item">
                    <a class="nav-link" href="updategoldloan.php">Update Gold Loan</a>
                  </li>
<li class="nav-item">
                    <a class="nav-link" href="deletegoldloan.php">Delete Gold Loan</a>
                  </li>
                </ul>
              </div>
            </li>
            <!-- end goldloan option -->

            </li>
            
            <?php } ?>
             <li class="nav-item">
              <a class="nav-link" href="loan_status.php">
                <img src="images/icons/6.png" alt="">
                <span class="menu-title">Loan Status</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="close_gold_loan.php">
                <img src="images/icons/6.png" alt="">
                <span class="menu-title">Close Gold Loan</span>
              </a>
            </li>
           <li class="nav-item">
              <a class="nav-link" href="apply_for_repledge.php">
                <img src="images/icons/6.png" alt="">
                <span class="menu-title">Replege Loan</span>
              </a>
            </li>
           
             <li class="nav-item">
              <a class="nav-link" href="close_repledge.php">
                <img src="images/icons/6.png" alt="">
                <span class="menu-title">Closing Repledge</span>
              </a>
            </li>
           
          </ul>
        </nav>

        <!-- partial -->
        <div class="content-wrapper">