<?php
  include_once "inc/header.php";
  include_once "inc/sidebar.php";
?>

     <h1 style="background-color: #28a745;color:#ffffff;text-align: center;font-family: MyWebFont;height:300px;" >Jayalakshmi Enterprises<br>Kml No<br>Manapady<br>Katoor Road</h1>            
    <div class="form-group row">
              <div class="col-md-6">
              
              </div>
          </div><!-- /.box-footer -->    
        </form>
       </div>            
  
<?php
include_once "inc/footer.php";
?>